Gravel Roads Prod version 1.0
August 14, 2002

	These road section objects are in essence clones from the standard MSTS road shapes and Dirt road shapes. Other than to rename the shape and image references to isolate them and adjusting sizes for the single lane sections, all that is really different is the ACE images used.

	They make use of already existing section indexes 0 thru 3 and 207 thru 224 as needed.

	The intent is to portray country roads and driveways that have been routinely covered with 1/4" to 1/2" gravel.

	The shape files are to be installed into the Global\Shapes folder.

	The textures go into the routes Textures folder, and optionally into the Template\Textures folder for new routes.

	This kit requires the pre-installation of the tsection.dat file version 7 or greater from the download library at Train-Sim.com.


Martyn T. Griffin
griffinmt@mindspring.com
