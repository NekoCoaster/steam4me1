MSTS ConrailIndy Custom Roads
by Bruce Bridges

DESCRIPTION
This package includes two 90-degree road curves and two airport runway sections
created especially for the Conrail Indianapolis Line Route. You must install this package
in order to use the route. These sections are included in the standardized tsection.dat
maintained by Train-Sim.Com. This package includes build 11 of the standard tsection.dat.
See the included tsection_readme.txt for further explanation.

INSTALLATION
Unzip all files to your Train Simulator\Global folder. IMPORTANT: Only overwrite 
tsection.dat if the version in this package is newer than the one you are currently using.

LEGAL/QUESTIONS/COMMENTS
You are allowed to use these sections in routes of your own design if you so choose, provided
that any distribution is free of charge and proper credit is given where it is due.

NOTE: The Conrail Indianapolis Line requires you to download and install ALL of the route zip files,
plus this file and XTracks Version 3.0 or later. Please do not contact me about installation problems
until you have downloaded and installed ALL of these as directed. The most common source of complaints
with the prior version of the Conrail route was failure to follow the instructions in XTracks. Follow
all instructions, and you should be OK.

For all other questions and/or comments, contact me at:
railfan727@yahoo.com

Thank you for downloading, and happy simming!