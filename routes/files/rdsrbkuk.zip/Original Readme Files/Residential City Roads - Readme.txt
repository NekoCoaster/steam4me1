Residential City Roads - V1.0
-----------------------------

These road sections are to be used for creating city housing 'suburbs', schools, parks and the occasional corner 7/11 store.

They consist of an Asphalt road 6 meters wide (2 lanes) with cement curbs along the sides. They also contain sidewalks that are just over 1 meter wide, and a 2 1/2 meter wide outlawn (boulevard) between the sidewalk and curbs. The outlawn area is transparent, resulting in the terrain texture being used for the lawn.

Manhole covers are to be found at each major intersection and at each dead end court.

The road pieces consist of the following:
- rd2lstrtcty.s
	- 14.28 meter long straight road section
- rd2lstrtctydrv.s
	- 14.28 meter long straight road section with two concrete 
	  driveway entrances included
- rd2l90cty.s
	- 90 degree road bend, including sidewalks and lawn plus 
	  two crosswalk sidewalks.
- rd2l22_5dcty.s
	- 22.5 degree turn version of the straight road, built on 
	  a 40 meter radius from the road center.
- rd2lctcty.s
	- straight road section with a court yard (circle) dead 
	  end, complete with sidewalks etc.
- rd2lintcty.s
	- a 19.97 meter by 19.97 meter intersection (at 90 
	  degrees), complete with crosswalk sidewalks.

In addition, the following static objects are included:
- rd2ldrventcty.s
	- a driveway entrance (from road to sidewalk) that is 3.8 meters 
	  wide tapering to about 2.9 meters wide. It must be placed 
	  manually (ie: via F3) over top of the outlawn transparency 
	  area. It is placed initially at about .05 meters higher than 
	  the road section. Adjust as needed after placing.
- rd2ldrvwaycty.s
	- a driveway section (beyond sidewalk) that is 2.9 meters 
	  wide and 5.8 meters long. Several may be needed for a 
	  full driveway. It must be placed manually (ie: via F3) 
	  over top of the lawn area beyond the sideway. It is 
	  placed initially at about .05 meters higher than 
	  the road section. Adjust as needed after placing.
- crosswalk.s
	- a 6 meter long double white stripe to be places at 
	  intersections or anywhere two opposing sidewalks approach 
	  the road.
- hydrant01.s
	- a short fire hydrant typically found along residential 
	  outlawn areas. This one has the caps painted yellow and 
	  is about 26 inches high.
- hydrant02.s
	- a tall fire hydrant typically found in older residential 
	  areas and in commercial areas. This one has the caps 
	  painted white and stands up to 44 inches high.
- mailbox.s
	- This is a USPS curbside style mailbox designed for drive 
	  up mailing of letters and small packages. It is typically 
	  placed along an outlawn where it can be reached through a 
	  car window.


Not Yet Ready (s/b by next version)
-------------
- FedEx letter drop

Installation (manual at present)
------------
1) Place all road section .s and .sd files into the Global\Shapes folder.
2) Place the static object .s and .sd files into the routes Shapes folder.
3) Place all .ace files into the desired route Texture folder.
**4) CAREFULLY place the first half of the Rd2lcty.dat file into the correct location of the Global\tsection.dat file ( this will be included in the near future, so make sure it is not a duplicate).
**5) CAREFULLY place the second half of the Rd2lcty.dat file into the correct location of the Global\tsection.dat file ( this will be included in the near future, so make sure it is not a duplicate).
6) Copy the entries of the rd2lcty.ref file into your routes .REF file.
7) Break out the backhoes and cranes and start building suburbia!


Assistance
----------
Please help by reporting any issues/suggestions/alterations to me via E-Mail. I will endeavor to address these ASAP.


Acknowledgements
----------------
I wish to thank, in particular, Scott Miller and Okarasa Ghia for helping me to get up and go work on using GMAX. Much much more to learn yet, but at least it is a start and they were very helpfull (no surprise!!)


Martyn T. Griffin
griffinmt@mindspring.com








