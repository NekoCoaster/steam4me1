<<<<<<Please turn word wrap on.>>>>>>

Readme.txt for "CYKWORKS Track Pack 2.0"

You may contact me with any questions / comments / suggestions at 
ccyko01@hotmail.com

Installation instructions:
1. Unzip files in the zipfile to a temporary folder.
2. Run the CYKTP2.exe installation file.
3. Follow the instructions contained within.
4. CYK Track Pack sections are ready to use.

This track pack is specifically designed for use with Chicago Elevated Railways packages, also released by CYKWORKS.

Use of this Track Pack requires Standardized tsection.dat file build 00022 or higher.


NOTE: Assuming instructions, and failure to follow instructions explicitly is
not supported, and any questions of such will not be answered. Though please
report any problems with installtion to me so we may come to a quick resolve, 
and I may be able to develop the software in a timely manner. Also, when
emailing with installation support questions please include a detailed description
of the operations performed, the software being used, and a description of the computer in which the setup was conducted, and what zip utility was used.

This add-on is released as Freeware. Copyright (C) CYKWORKS.  As 
freeware you are permitted to distribute this
archive subject to the following conditions,

- The contents of this file, in whole or part may not be used in any other package.
If you wish to use these sections in an add-on route you may do so, but this package must be downloaded seperatly. 

- No charge may be made for this archive without expressed consent 
by the author(s) of the products contained within.

- The authors' rights and wishes concerning this archive must be
respected.
