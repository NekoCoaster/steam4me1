DualTracks v1.0 - Installation
--------------------------------
1. First make a copy of you MSTS GLOBAL folder so that if you encounter any problems, you can recover from them.

2. Copy all files in GLOBAL/SHAPES into your MSTS GLOBAL/SHAPES folder.

3. DualTracks comes with matched textures for standard, narrow, and dual gauge tracks:
	acleantrack1.ace
	acleantrack2.ace
	DCleanTrack1.ace
	DCleanTrack2.ace
	NCleanTrack1.ace
	NCleanTrack2.ace
Each route that will use DualTracks will need a copy of all 
of the textures.  If you downloaded a premade route, it may already 
have its own versions of these textures.  Or you may want to use other standard or narrow gauge textures from other routes and only use 
the dual gauge textures from this pacakge.  Or you may be getting 
ready to build a new route and need all of the textures. After 
deciding which you need, copy the relevant files from 
TEXTURES to your <route>/TEXTURES folder.
Then copy the snow counterparts of those same texture files from TEXTURES/SNOW to your <route>/TEXTURES/SNOW folder.

If you prefer, you can copy the entire TEXTURES folder answering "no" when prompted to avoid overwriting any particular preexisting textures 
you want to keep.


4. Update your global tsection.dat to build 00015 or greater.  
For convenience, DualTracks comes with tsection.dat build 00015 file, 
but does NOT include installation instructions for it.

	IMPORTANT: If you have never used a standardized tsection.dat 
	(or don't know what it is), you should download the latest 		tsection.dat from the www.train-sim.com file library and read 
	the documentation that comes with it before copying this file 
	into your MSTS installation.

If you're ready to use the tsection.dat file, then copy it from
this package's GLOBAL folder to your MSTS's GLOBAL folder.

5. Installation is complete.


Notes for Running Trains
-------------------------
Trains running over the narrow gauge side work the same as on any 
single gauge track.  Switches and derails will animate when thrown.

Trains running over the standard gauge side of the dual gauge will be able to throw switches and derails functionally (as seen in 
the onscreen "F8" window), but will not be animated.


Notes for Building Routes
--------------------------
Although DualTracks does not require Xtracks, Xtracks narrow gauge pieces are needed to complete some track arrangements (such as diverging gauge switches), and the DualTracks reference route does require Xtracks as its purpose is to illustrate all arrangements.

Track Sections with an "LC" name suffix are "left common" rail, meaning the rail that is common to both gauges is on the left given the default orientation (curving to the left for curves, and as viewed from the points for a switch).  Similarly, "RC" indicates "right common". Note that for curves, "LC" is synonymous with "inside common" and "RC" with "outside common", which is easier to remember given varying viewpoints.

When placing dual gauge sections, use the "T" key to flip  the section around until it lines up properly.  Care is particularly needed for the "Pnt" sections on the point end.  It possible to get them attached inline but overlapped, resulting in the annoying (but not dangerous) situation where blue poles remain unconnected.  Placing the "D1tPntEnd" before the "Pnt" will prevent this confusing situation.

Some narrow gauge shapes intended for use only in dual gauge applications use standard-sized rail for a matching appearance (N1t40mStrt, N1t164r10dLC[RC], N1tPnt10dLft[Rgt]164rMnlLC[RC]).

"Pnt0d" or zero-degree (non-diverging) switches are included.  For these, the straight path is the longer leg, and the diverging path is the shorter leg.  Having both left and right varieties allows the switch window in the simulator (F8 view) to show the diverging route on the proper side (as limited by the known MSTS bug in the switch illustration). Zero-degree switches can be used as simulated accidental derail locations where the track continues slightly underground connected to the divering edge, allowing the 'rerailing' of 'derailed' cars as activities.  They may also be useful in breaking long continuous runs of rail into shorter runs to avoid the accumulated position error that causes derailments and broken couplers.  The community is still looking into better solutions to this problem.  Zero-degree switches could also be adapted to operating swing/lift bridges if a new shape file is made for them with the proper animated part (though such a modification would 
affect ALL installed routes and would NOT be suitable for distribution).

"Derail" sections are based on zero-degree switches. The shorter legs are the diverging path, and should be left unconnected.  With no rail connected to the diverging route, if the train attempts to run the derail it will indeed derail (by the simulation mechanism of running out of track).  Note that because it is really a switch, the derail can be run in the reverse direction without derailing, so place the derail in the 
appropriate direction for your intended use.  Unfortunately, the interpretation of the tsection.dat entries means that having the F8 switch illustration indicate straight when clear is contrary to the desire to have the derail in place (ready to derail) as the default configuration.  Rather than have the F8 view indicate straight but derail, the derails are configured to indicate properly in the F8 view and be down (clear for running) as the default configuration.

The "Center" sections center the narrow within the standard gauge.  This is most often used in servicing areas to allow a pit to be centered under equipment of both gauges.  These centering sections are active switches, and just as the prototype they must be thrown properly for the given gauge.  For standard gauge, the switch should be thrown to continue straight (as indeed the standard rails go straight).  For narrow gauge, the switch should be thrown to take the diverging route (as the narrow does make the jog toward the center).  The two short legs on the switch should be left unconnected, so that having the switch improperly aligned will cause a derailment as is prototypical. 

Please consult the DualTracks reference route for specific track arrangements.  

There are a few properties of dual gauge tracks as implemented in DualTracks that are not obvious but must be considered when laying rail and also when creating activities.

When tracks are centered (sharing the same centerlines), as after a "Pnt0d" switch, "Center", or "Derail", care must be taken that the connections of any such aligned tracks be staggered along the length of the track.  For example, after a "Center" section, there is a narrow track and a standard track, at no point may any end of any narrow track section align with the end of a standard track section.  Any such aligned sections may cause MSTS to confuse which section connects to which.  Even if placed carefully and in order the first time, any rebuild of the track database will likely fail.

 (dual)   "Center"       (standard sections)
========+##########+---------+----------+          (GOOD)
         ######+--------+--------+---------+
                       (narrow sections)	

 (dual)   "Center"       (standard sections)
========+##########+---------+----------+          (BAD)
         ######+--------+--------+------+
                       (narrow sections)	

 (dual)   "Center"       (standard sections)
========+##########+---------+----------+          (BAD)
         ######+--------+--------+------+--+
                       (narrow sections)	

Activities running on dual gauge track have proven problematic. 

Activities running over the standard gauge side must have 'start','stop', 'reverse', and possibly other key points located on standard gauge ONLY track sections.  If any of these key points are on the standard side of dual gauge, the Activity Editor will become confused, the green path line may jump to the narrow side while the dots remain on the standard side, and you will get a "Failed To Load" error trying to leave the path editor.

Activities running on dual gauge with a passing siding cause sometimes cause broken paths for an unknown reason, but not always.

Despite the above general activity path problems, there are exceptions that inexplicably work, other arrangements that fail, and very often the success of a path depends on the state of the Activity Editor.  Exiting, restarting and relaying the path may work, repeatedly toggling switch points back and forth while laying the path may fix a path, or creating a short but good path first and later reloading and extending it may help.  It is hoped that more testing will expose the problems, or that a future version of MSTS will not exhibit the same problems.

Signalling - There has been no attempt to place signals on dual gauge track.  Certainly the two gauges would have to have to be signaled separately, just as an ordinary double track.  Behavior in the Activity Editor setting paths suggests that signals will be problematic.
The author of DualTracks will not be exploring signalling on dual gauge.
